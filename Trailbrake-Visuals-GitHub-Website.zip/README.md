# Trailbrake Visuals — GitHub Pages

This is a static website for Trailbrake Visuals.

## Files
- `index.html` — page structure/content
- `style.css` — design/responsive styling
- `script.js` — mobile menu + navigation
- `assets/trailbrake-logo.png` — supplied Trailbrake Visuals logo

## Publish for free with GitHub Pages

1. Create a free GitHub account at https://github.com/
2. Create a new **public** repository.
3. Upload everything in this folder to the repository.
4. Go to **Settings → Pages**.
5. Under the publishing/source section, choose the `main` branch and `/ (root)`.
6. Save.
7. GitHub will publish the site at your GitHub Pages address.

## Important before publishing
- Replace the `#` Instagram/TikTok/YouTube links in `index.html`.
- Replace `hello@trailbrakevisuals.com` with your real email address.
- Replace the placeholder gallery cards with your own photographs.
- Keep your original logo in `assets/trailbrake-logo.png`.

The site deliberately uses abstract placeholders rather than invented motorsport photographs, so the portfolio represents your actual work.
